# frozen_string_literal: true

# Fact: udev
#
# Purpose:
#   Provide access to udev db
#
# Resolution:
#   Check if the the kernel is linux and that the udevadm command is present.

Facter.add(:udevadm) do
  confine kernel: :linux

  setcode do
    Facter::Util::Resolution.which('udevadm')
  end
end

Facter.add(:udev) do
  confine kernel: :linux
  confine(:udevadm) { |x| !!x }

  def parse_dev(str)
    d = {}

    str.split(%r{\n}).each do |l|
      (type, data) = l.split(': ', 2)
      # see https://github.com/systemd/systemd/blob/a7b2aa658f35f4b9e91915eaa72afa648d0f9119/src/udev/udevadm-info.c#L182
      case type
      when 'N'
        d[:name] = data
      when 'P'
        d[:path] = data
      when 'S'
        d[:link].nil? ? d[:symlink] = [data] : d[:symlink].push(data)
      when 'E'
        (key, value) = data.split('=', 2)
        d[:property].nil? ? d[:property] = { key => value } : d[:property][key] = value
      when 'L'
        d[:priority] = data.to_i
      else
        raise "Unknown record: #{l}"
      end
    end

    d
  end

  setcode do
    info = Facter::Util::Resolution.exec('udevadm info -e')
    dev = info.split(%r{^\n}).map! do |d|
      parse_dev(d)
    end

    # The udev db contains information on [many] devices which do not have a
    # /dev/<file>. which are filtered out as they do not have a convenient
    # "name" by which to index them.
    named_dev = {}
    dev.each do |x|
      if x.has_key?(:name)
        named_dev[x[:name]] = x
      end
    end

    named_dev
  end
end
